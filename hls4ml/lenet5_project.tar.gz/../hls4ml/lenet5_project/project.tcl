variable project_name
set project_name "myproject"
variable backend
set backend "vivado"
variable part
set part "xc7z010clg400-1"
variable clock_period
set clock_period 5
variable clock_uncertainty
set clock_uncertainty 12.5%
